package ru.yandex.practicum.filmorate.exeption;

public class ValidationException extends Exception {
}
